import asyncio
import html
import json
import re
import time
from typing import List, Optional

from astrbot.api import AstrBotConfig, logger
from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.platform import MessageType
from astrbot.api.star import Context, Star


class InjectionBlocker(Star):
    """AstrBot 注入拦截器插件。

    在消息进入 LLM / 其它插件之前，检查是否包含用户配置的拦截词。
    命中后立即终止事件传播，并可选地向发送者回复提示。
    """

    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.config = config

        # 内存中的拦截词缓存
        self.blocked_words: List[str] = []
        self._loaded = False
        self._last_load_failed_at = 0.0
        self._load_retry_interval = 30.0  # 加载失败后的重试冷却时间（秒）
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------
    # 存储与匹配辅助逻辑
    # ------------------------------------------------------------
    async def _load_blocked_words_locked(self) -> bool:
        """从 KV 存储加载拦截词列表（假定调用方已持有 self._lock）。

        返回 True 表示加载成功或已加载；False 表示加载失败（不阻断消息）。
        """
        if self._loaded:
            return True

        now = time.time()
        if now - self._last_load_failed_at < self._load_retry_interval:
            return False

        try:
            raw = await self.get_kv_data("blocked_words", "[]")

            # 兼容不同存储返回类型：可能是字符串，也可能已被 AstrBot 解析为对象
            if raw is None:
                raw_data = []
            elif isinstance(raw, str):
                raw_data = json.loads(raw) if raw else []
            else:
                raw_data = raw

            if isinstance(raw_data, list):
                self.blocked_words = [
                    str(item).strip()
                    for item in raw_data
                    if item is not None and str(item).strip() != ""
                ]
            else:
                self.blocked_words = []

            self._loaded = True
            self._last_load_failed_at = 0.0
            return True
        except Exception as e:
            logger.error(f"读取拦截词列表失败：{e}")
            self._last_load_failed_at = time.time()
            self._loaded = False
            return False

    async def _save_blocked_words_locked(self) -> None:
        """将当前拦截词列表写入 KV 存储（假定调用方已持有 self._lock）。"""
        await self.put_kv_data(
            "blocked_words", json.dumps(self.blocked_words, ensure_ascii=False)
        )

    def _find_matched_word(self, text: str, words: Optional[List[str]] = None) -> Optional[str]:
        """检查文本是否命中某个拦截词，返回命中的词 / 正则；未命中返回 None。"""
        if not text:
            return None
        if words is None:
            words = self.blocked_words
        if not words:
            return None

        case_sensitive = bool(self.config.get("case_sensitive", False))
        regex_mode = bool(self.config.get("regex_mode", False))

        if regex_mode:
            flags = 0 if case_sensitive else re.IGNORECASE
            for pattern in words:
                try:
                    if re.search(pattern, text, flags):
                        return pattern
                except re.error as e:
                    logger.warning(f"正则表达式无效，已忽略该拦截词：{pattern!r}：{e}")
            return None

        # 普通子串匹配
        lower_text = text if case_sensitive else text.lower()
        for word in words:
            target = word if case_sensitive else word.lower()
            if target and target in lower_text:
                return word
        return None

    # ------------------------------------------------------------
    # 全局消息过滤入口
    # ------------------------------------------------------------
    def _build_check_text(self, event: AstrMessageEvent) -> str:
        """构造用于拦截检查的文本：正文 + 引用等消息链中携带的文本。

        event.message_str 只包含纯文本正文，引用消息的原文在消息链的
        Reply 段里（Reply.message_str），不检查的话注入内容可以借引用绕过。
        get_message_outline() 会把正文与引用原文拼成概要文本。
        """
        text = (event.message_str or "").strip()
        if not self.config.get("check_quote", True):
            return text
        try:
            outline = event.get_message_outline() or ""
        except Exception:
            outline = ""
        if outline.strip():
            return outline.strip()
        return text

    @filter.event_message_type(filter.EventMessageType.ALL)
    async def on_message(self, event: AstrMessageEvent):
        """监听所有消息，在转发给 LLM / 其它插件前执行拦截判断。"""
        if not self._scope_enabled(event):
            return

        cmd_text = (event.message_str or "").strip()

        # 放行插件自身的 /pblock 管理命令，避免误拦截
        if cmd_text.startswith("/pblock"):
            return

        text = self._build_check_text(event)

        async with self._lock:
            load_ok = await self._load_blocked_words_locked()
            if not load_ok or not self.blocked_words:
                # 存储不可读或没有拦截词：不拦截，按正常流程放行
                return
            words = list(self.blocked_words)

        matched_word = self._find_matched_word(text, words)
        blocked_image_forward = False

        # 基础文本未命中时，尝试展开合并转发等卡片内容再检查一次
        if not matched_word and self.config.get("check_forward", True):
            try:
                expanded = await asyncio.wait_for(
                    self._expand_forward_text(event),
                    timeout=4.0,
                )
            except Exception as e:
                logger.warning(f"展开合并转发内容失败（跳过）: {e}")
                expanded = ""
            # _expand_forward_text 现在返回 (展开文本, 是否含图片)
            if isinstance(expanded, tuple):
                expanded, has_image = expanded
            else:
                has_image = False
            if expanded:
                matched_word = self._find_matched_word(text + " " + expanded, words)
            # 带图片的合并转发/聊天记录：即使没命中拦截词也直接拦掉
            if (
                not matched_word
                and has_image
                and bool(self.config.get("block_forward_image", True))
            ):
                blocked_image_forward = True

        if matched_word or blocked_image_forward:
            # 终止事件传播，确保后续插件和 LLM 不再处理该消息
            event.stop_event()

            # 记录拦截日志（DEBUG 级别，由 show_nickname 配置是否显示昵称）
            sender_info = ""
            if self.config.get("show_nickname", False):
                try:
                    sender_info = f"，发送者: {event.get_sender_name()}"
                except Exception:
                    pass
            if blocked_image_forward:
                logger.info(f"消息已被注入拦截器拦截{sender_info}，原因: 带图片的合并转发/聊天记录")
            else:
                logger.info(f"消息已被注入拦截器拦截{sender_info}，命中拦截词: {matched_word}")

            # 可选：向被拦截消息的发送者回复提示
            if self.config.get("block_message", False):
                try:
                    reply_text = self.config.get("block_message_text", "").strip()
                    if not reply_text:
                        reply_text = "您的消息包含不允许的内容，已自动拦截。"
                    reply_text = reply_text.replace(
                        "{word}",
                        str(matched_word or "带图片的聊天记录"),
                    )
                    await event.send(event.plain_result(reply_text))
                except Exception as e:
                    logger.warning(f"发送拦截提示失败：{e}")

    # ------------------------------------------------------------
    # 群聊/私聊独立启停与合并转发展开
    # ------------------------------------------------------------
    def _scope_enabled(self, event: AstrMessageEvent) -> bool:
        """按会话类型判断该场景是否启用拦截。"""
        if not event:
            return True
        try:
            msg_type = event.get_message_type()
        except Exception:
            msg_type = None
        if msg_type == MessageType.GROUP_MESSAGE:
            return bool(self.config.get("group_enabled", True))
        if msg_type == MessageType.FRIEND_MESSAGE:
            return bool(self.config.get("private_enabled", True))
        # 其他类型：沿用默认启用，避免误伤未知渠道
        return True

    def _looks_like_forward(self, seg) -> bool:
        """判断一个消息段是否可能是合并转发/转发节点。"""
        if isinstance(seg, dict):
            return str(seg.get("type") or "").lower() in (
                "forward",
                "node",
                "nodes",
                "json",
            )
        name = type(seg).__name__.lower()
        # 注意：reply（引用消息）不是合并转发，不应触发“带图转发”拦截，
        # 否则引用一张图让 bot 识图也会被当成带图聊天记录误拦。
        return name in ("forward", "node", "nodes", "json")

    def _seg_is_text_like(self, seg) -> bool:
        if isinstance(seg, dict):
            return str(seg.get("type") or "").lower() in ("text", "plain")
        name = type(seg).__name__.lower()
        return name in ("plain", "text")

    def _seg_text_value(self, seg) -> str:
        if isinstance(seg, dict):
            data = seg.get("data")
            if not isinstance(data, dict):
                data = {}
            return str(data.get("text") or "")
        return str(getattr(seg, "text", "") or "")

    def _flatten_segments(
        self,
        segs,
        out: list,
        depth: int,
        forward_ids: list,
        has_image: Optional[list] = None,
        flag_images: bool = True,
    ) -> None:
        """递归收集消息段中的文本与转发 id。

        has_image 为可选单元素列表哨兵；展开过程中见到图片段时置 True，
        用于“带图的聊天记录直接拦截”判定。
        flag_images 控制是否把当前层遇到的图片计入 has_image。reply（引用
        消息）里的普通图片不算“转发聊天记录带图”，递归引用链时传 False，
        避免用户引用一张图让 bot 识图也被一刀切拦截。
        """
        if depth > 5 or not isinstance(segs, list):
            return
        for seg in segs:
            if isinstance(seg, dict):
                seg_type = str(seg.get("type") or "").lower()
                data = seg.get("data")
                if not isinstance(data, dict):
                    data = {}
                if seg_type in ("text", "plain"):
                    t = str(data.get("text") or "")
                    if t:
                        out.append(t)
                elif seg_type in ("image", "img"):
                    out.append("[图片]")
                    if has_image is not None and flag_images:
                        has_image[0] = True
                elif seg_type == "forward":
                    fid = str(data.get("id") or data.get("resid") or "").strip()
                    if fid and fid not in forward_ids:
                        forward_ids.append(fid)
                    inner = data.get("messages") or data.get("content")
                    if inner:
                        # 卡内内容必然是聊天记录本体，内部图片参与拦截
                        self._flatten_segments(inner, out, depth + 1, forward_ids, has_image, flag_images=True)
                elif seg_type == "node":
                    inner = data.get("content") or data.get("message")
                    if inner:
                        self._flatten_segments(inner, out, depth + 1, forward_ids, has_image, flag_images=True)
                elif seg_type == "json":
                    self._digest_json_card(data, out, forward_ids)
            else:
                name = type(seg).__name__.lower()
                if name in ("plain", "text"):
                    t = str(getattr(seg, "text", "") or "")
                    if t:
                        out.append(t)
                elif name == "image":
                    out.append("[图片]")
                    if has_image is not None and flag_images:
                        has_image[0] = True
                elif name == "forward":
                    fid = str(getattr(seg, "id", "") or "").strip()
                    if fid and fid not in forward_ids:
                        forward_ids.append(fid)
                elif name == "nodes":
                    for node in getattr(seg, "nodes", []) or []:
                        content = getattr(node, "content", None) or []
                        # 转发节点内容必然属于聊天记录，内部图片参与拦截
                        self._flatten_segments(content, out, depth + 1, forward_ids, has_image, flag_images=True)
                elif name == "node":
                    content = getattr(seg, "content", None) or []
                    if content:
                        self._flatten_segments(content, out, depth + 1, forward_ids, has_image, flag_images=True)
                elif name == "reply":
                    # 引用消息：原文文本照常收集参与拦截词检查，但其中的
                    # 普通图片不算“转发聊天记录带图”，避免引用识图被误拦。
                    chain = getattr(seg, "chain", None) or []
                    if chain:
                        self._flatten_segments(chain, out, depth + 1, forward_ids, has_image, flag_images=False)
                elif name == "json":
                    data = getattr(seg, "data", None) or {}
                    if not isinstance(data, dict):
                        data = {}
                    self._digest_json_card(data, out, forward_ids)

    def _digest_json_card(self, data: dict, out: list, forward_ids: list) -> None:
        """尽力解析 QQ 合并转发 JSON 卡片：摘取摘要文本与 resid。"""
        try:
            raw = data.get("data")
            if not raw:
                raw = data.get("content")
            if not isinstance(raw, str):
                return
            raw = html.unescape(raw).replace("\\/", "/")
            obj = json.loads(raw)
            if not isinstance(obj, dict) or obj.get("app") != "com.tencent.multimsg":
                return
            detail = ((obj.get("meta") or {}).get("detail")) or {}
            news = detail.get("news")
            if isinstance(news, list):
                for item in news:
                    if not isinstance(item, dict):
                        continue
                    t = item.get("text")
                    if isinstance(t, str) and t.strip():
                        out.append(t.strip())
            resid = detail.get("resid")
            if isinstance(resid, str) and resid.strip() and resid not in forward_ids:
                forward_ids.append(resid.strip())
        except Exception:
            return

    async def _call_platform_action(self, event: AstrMessageEvent, action: str, **kwargs):
        bot = getattr(event, "bot", None)
        api = getattr(bot, "api", None)
        call_action = getattr(api, "call_action", None)
        if not callable(call_action):
            return None
        return await call_action(action, **kwargs)

    async def _fetch_forward_payload(self, event: AstrMessageEvent, fid: str):
        """按兼容参数尝试拉取一条合并转发的内容。"""
        safe_id = str(fid or "").strip()
        if not safe_id:
            return None
        attempts = [
            ("get_forward_msg", {"id": safe_id}),
            ("get_forward_msg", {"message_id": safe_id}),
            ("get_forward_msg", {"res_id": safe_id}),
            ("get_msg", {"message_id": safe_id}),
        ]
        if safe_id.isdigit():
            attempts.insert(0, ("get_forward_msg", {"id": int(safe_id)}))
        for action, kwargs in attempts:
            try:
                raw = await self._call_platform_action(event, action, **kwargs)
            except Exception:
                continue
            if raw:
                return raw
        return None

    def _forward_nodes(self, payload) -> list:
        """从平台返回里提取节点列表。"""
        if isinstance(payload, dict):
            data = payload.get("data")
            if isinstance(data, dict):
                for key in ("messages", "message", "nodes"):
                    val = data.get(key)
                    if isinstance(val, list) and val:
                        return val
            for key in ("messages", "nodes"):
                val = payload.get(key)
                if isinstance(val, list) and val:
                    return val
        return []

    def _seg_is_reply(self, seg) -> bool:
        """判断消息段是否是引用（reply/quote）段。"""
        if isinstance(seg, dict):
            return str(seg.get("type") or "").lower() in ("reply", "quote")
        return type(seg).__name__.lower() in ("reply", "quote")

    def _chain_has_forward(self, segs, depth: int = 0) -> bool:
        """递归判断消息链里是否藏着转发/聊天记录卡。

        只看顶层会把“引用一条转发消息”漏掉：此时转发卡嵌在被引用
        消息的 reply 链内部，顶层只有 reply 段。递归后两种都能命中，
        普通图片/文本引用（reply 链里没有转发卡）则不受影响。
        """
        if depth > 5 or not isinstance(segs, list):
            return False
        for seg in segs:
            if self._looks_like_forward(seg):
                return True
            children = None
            if isinstance(seg, dict):
                seg_type = str(seg.get("type") or "").lower()
                data = seg.get("data")
                if not isinstance(data, dict):
                    data = {}
                if seg_type in ("reply", "quote"):
                    children = data.get("chain") or data.get("message") or data.get("content")
                else:
                    children = (
                        data.get("content")
                        or data.get("messages")
                        or data.get("message")
                        or data.get("chain")
                    )
            else:
                name = type(seg).__name__.lower()
                if name in ("reply", "quote"):
                    children = getattr(seg, "chain", None)
                elif name in ("node", "nodes"):
                    children = None  # node 内容由 _looks_like_forward 覆盖不了时递归 nodes
                    if name == "nodes":
                        children = getattr(seg, "nodes", None)
                    else:
                        children = getattr(seg, "content", None)
            if isinstance(children, dict):
                children = [children]
            if isinstance(children, list) and self._chain_has_forward(children, depth + 1):
                return True
        return False

    async def _expand_forward_text(self, event: AstrMessageEvent):
        """入口兜底：递归展开消息链中的合并转发卡片文本。

        返回 (展开文本, 是否含图片)。平台不支持拉取子消息时可能拿不到
        图片信息，调用方应保守处理（拿不到内容不会误判为带图）。

        引用普通图片/文本消息属于用户主动交互（如引用一张图让 bot 识图），
        不会被当成“带图聊天记录”；但引用里若藏着转发/聊天记录卡
        （含转发消息），卡内图片照常参与“带图即拦”判定。
        """
        chain = []
        try:
            chain = list(event.get_messages() or [])
        except Exception:
            chain = []
        if not self._chain_has_forward(chain):
            return "", False

        # 根消息带引用时，展开出来的图片不触发 block_forward_image
        root_has_reply = any(self._seg_is_reply(seg) for seg in chain)
        flag_images = not root_has_reply

        out: list[str] = []
        forward_ids: list[str] = []
        has_image: list = [False]
        self._flatten_segments(chain, out, 0, forward_ids, has_image, flag_images=flag_images)

        visited = set()
        pending = list(forward_ids)
        while pending and len(visited) < 8:
            fid = pending.pop(0)
            if not fid or fid in visited:
                continue
            visited.add(fid)
            payload = await self._fetch_forward_payload(event, fid)
            if not payload:
                continue
            for node in self._forward_nodes(payload):
                if isinstance(node, dict):
                    node_data = node.get("data")
                    if isinstance(node_data, dict):
                        content = node_data.get("content") or node_data.get("message")
                    else:
                        content = node.get("content") or node.get("message")
                    if isinstance(content, list):
                        # 能 fetch 到节点就说明确实是聊天记录/合并转发卡片；
                        # 无论是否被引用，其内部图片都应参与拦截判定
                        self._flatten_segments(content, out, 0, pending, has_image, flag_images=True)

        # 去重并限制输出长度
        seen_text = set()
        lines = []
        for t in out:
            t = str(t).strip()
            if not t or t in seen_text:
                continue
            seen_text.add(t)
            lines.append(t)
            if len(lines) >= 200:
                break
        return "\n".join(lines), has_image[0]

    # ------------------------------------------------------------
    # LLM 请求前：历史上下文注入清洗
    # ------------------------------------------------------------
    def _hit_context_content(self, content, words: List[str]) -> Optional[str]:
        """检查一条历史消息的 content 是否命中拦截词。

        content 可能是纯字符串，也可能是多模态列表（部分 provider 使用
        [{"type": "text", "text": ...}, ...]）。命中返回命中的词 / 正则。
        """
        if isinstance(content, str):
            return self._find_matched_word(content, words)
        if isinstance(content, list):
            text_parts = []
            for item in content:
                if isinstance(item, dict):
                    for key in ("text", "content", "alt", "name"):
                        val = item.get(key)
                        if isinstance(val, str) and val.strip():
                            text_parts.append(val)
                            break
                elif isinstance(item, str):
                    text_parts.append(item)
                else:
                    val = getattr(item, "text", "") or getattr(item, "content", "")
                    if isinstance(val, str) and val.strip():
                        text_parts.append(val)
            return self._find_matched_word(chr(10).join(text_parts), words)
        return None

    async def _notice_blocked(self, event: AstrMessageEvent, matched_word: str, scope: str):
        """按 block_message 配置发送拦截提示（尽力而为，失败不抛错）。"""
        try:
            if self.config.get("block_message", False):
                await event.send(
                    event.plain_result(
                        f"检测到上下文中的注入内容（命中拦截词），本次请求已安全处理：{scope}。"
                    )
                )
        except Exception as e:
            logger.warning(f"发送上下文拦截提示失败：{e}")
        logger.info(f"LLM 请求已被注入拦截器处理（{scope}），命中拦截词: {matched_word}")

    async def _precheck_image_caption(
        self, image_urls: list, words: List[str]
    ) -> Optional[str]:
        """用配置的识图模型把图片文字转写出来并检查，命中返回命中的词。"""
        provider_id = str(self.config.get("image_caption_provider_id") or "").strip()
        if not provider_id:
            return None
        try:
            provider = self.context.get_provider_by_id(provider_id)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"获取识图模型失败（跳过图片预检）: {e}")
            return None
        if provider is None:
            return None
        prompt = str(
            self.config.get("image_caption_prompt")
            or "请逐字转写图片中出现的所有文字，不要输出其它内容。"
        ).strip()
        resp = await provider.text_chat(prompt=prompt, image_urls=image_urls)
        text = str(getattr(resp, "completion_text", "") or "")
        return self._find_matched_word(text, words)

    def _iter_llm_injected_surfaces(self, req):
        """收集框架/陪伴插件在请求里后注入的文本面。

        这类文本不在 req.prompt / req.contexts 中（例如合并转发聊天记录、
        引用链原文、图片视觉摘要），但会追加进 req.system_prompt 或
        req.extra_user_content_parts，是 on_message 与历史上下文都覆盖
        不到的特殊路径。产出 (kind, position, text)。
        """
        system_prompt = str(getattr(req, "system_prompt", "") or "")
        marker_match = None
        if system_prompt and "private_companion_" in system_prompt:
            # 命中两种情况之一即认为该处开始是插件后注入的内容：
            # 1) 直接拼入的注释 marker：<!-- private_companion_xxx_v1 -->
            # 2) 会话注入计划渲染后的 XML 块：<private_companion_context>
            #    （陪伴插件的合并转发/引用链/识图摘要按计划在很晚的
            #     priority 才渲染成这种带标签块，没有注释 marker）
            for pattern in (
                r"<!--\s*private_companion_[a-zA-Z0-9_]+_v1\s*-->",
                r"<private_companion_context>",
            ):
                m = re.search(pattern, system_prompt)
                if m is not None:
                    marker_match = m
                    break
        if marker_match is not None:
            # 取第一个注入标签起扫描到末尾：该位置起基本都是由插件
            # 追加的注入内容，从它开始扫描可以覆盖连续追加的多个注入块。
            yield ("system_prompt", marker_match.start(), system_prompt[marker_match.start():])

        extra_parts = getattr(req, "extra_user_content_parts", None)
        if isinstance(extra_parts, list):
            for part in extra_parts:
                if isinstance(part, dict):
                    text = ""
                    for key in ("text", "content", "alt", "name"):
                        val = part.get(key)
                        if isinstance(val, str) and val.strip():
                            text = val
                            break
                else:
                    text = str(getattr(part, "text", "") or getattr(part, "content", "") or "")
                if text.strip():
                    yield ("extra_user_content_parts", part, text)

    @filter.on_llm_request(priority=-300000)
    async def on_llm_request(self, event: AstrMessageEvent, req):
        """在请求发送给 LLM 前检查历史上下文，防止先前注入的话术在后续被读入执行。

        策略由 context_block_mode 控制：
          - sanitize：把命中的历史消息替换为占位符后继续回复（推荐，默认）；
          - reject  ：发现历史中含拦截词，直接终止本次 LLM 请求。
        当前请求（req.prompt）本身命中时始终终止，避免注入指令进入模型。

        使用极低的 priority 执行：陪伴插件注入的合并转发/引用链/识图摘要通常
        先登记在会话注入计划里，直到 -260000 才被渲染进 system_prompt，因此这里
        必须排得更靠后（-300000），确保兜底时能看到它们真正进入请求的文本面。
        """
        if not self.config.get("context_block_enabled", True):
            return

        if not self._scope_enabled(event):
            return

        async with self._lock:
            load_ok = await self._load_blocked_words_locked()
            if not load_ok or not self.blocked_words:
                return
            words = list(self.blocked_words)

        # 0) 图片内容预检：主模型若直接多模态吃图，图片里的文字本插件看不到。
        #    可配置识图模型，先把图片转成文本再扫一遍关键词，命中即终止。
        if bool(self.config.get("image_caption_precheck", False)):
            image_urls = [
                u for u in (getattr(req, "image_urls", None) or []) if str(u).strip()
            ]
            if image_urls:
                try:
                    hit_img = await self._precheck_image_caption(image_urls, words)
                except Exception as e:  # noqa: BLE001
                    logger.warning(f"图片内容预检失败（跳过本次预检）: {e}")
                    hit_img = None
                if hit_img:
                    event.stop_event()
                    await self._notice_blocked(event, hit_img, "图片内容")
                    return

        mode = str(self.config.get("context_block_mode", "sanitize")).strip().lower()
        placeholder = str(self.config.get("context_block_placeholder", "[已拦截]"))

        # 1) 当前请求本身带毒：直接终止（为 on_message 漏过的特殊路径兜底）
        hit_current = self._find_matched_word(req.prompt or "", words)
        if hit_current:
            event.stop_event()
            await self._notice_blocked(event, hit_current, "当前请求")
            return

        # 2) 扫描历史上下文
        if mode == "reject":
            for ctx in req.contexts or []:
                matched = self._hit_context_content(ctx.get("content"), words)
                if matched:
                    event.stop_event()
                    await self._notice_blocked(event, matched, "历史上下文")
                    return
            for kind, _, text in self._iter_llm_injected_surfaces(req):
                matched = self._find_matched_word(text, words)
                if matched:
                    event.stop_event()
                    await self._notice_blocked(event, matched, f"请求注入面({kind})")
                    return
            return

        # sanitize：洗掉历史里的毒话再继续
        hit_words = []
        for ctx in req.contexts or []:
            if not isinstance(ctx, dict):
                continue
            matched = self._hit_context_content(ctx.get("content"), words)
            if matched:
                if isinstance(ctx.get("content"), list):
                    ctx["content"] = [{"type": "text", "text": placeholder}]
                else:
                    ctx["content"] = placeholder
                hit_words.append(matched)

        # 3) 清洗请求注入面（合并转发/引用链/识图等插件后注入的文本）
        for kind, position, text in self._iter_llm_injected_surfaces(req):
            matched = self._find_matched_word(text, words)
            if not matched:
                continue
            if kind == "system_prompt":
                # 只替换插件注入段（第一个 private_companion marker 起），
                # 保留前面的核心系统指令，避免误伤。
                system_prompt = str(getattr(req, "system_prompt", "") or "")
                req.system_prompt = system_prompt[:position] + placeholder
            else:
                if isinstance(position, dict):
                    position["text"] = placeholder
                    position["content"] = placeholder
                else:
                    try:
                        position.text = placeholder
                    except Exception:
                        pass
            hit_words.append(matched)
        if hit_words:
            logger.info(
                f"已清洗 {len(hit_words)} 条含注入内容的历史消息，命中拦截词: {hit_words[0]}"
            )

    # ------------------------------------------------------------
    # /pblock 命令组
    # ------------------------------------------------------------
    @filter.command_group("pblock")
    def pblock(self):
        """AstrBot 注入拦截器管理命令组"""
        pass

    @filter.permission_type(filter.PermissionType.ADMIN)
    @pblock.command("add")
    async def pblock_add(self, event: AstrMessageEvent):
        """添加拦截词：/pblock add <word>"""
        match = re.match(r"^\s*(?:\[(?:CQ:at|At)[^\]]*\]\s*)?/?pblock\s+add\s+(.+)$", event.message_str.strip(), re.S)
        if not match:
            yield event.plain_result("用法：/pblock add <拦截词>")
            return

        word = match.group(1).strip()
        if not word:
            yield event.plain_result("拦截词不能为空。")
            return

        async with self._lock:
            load_ok = await self._load_blocked_words_locked()
            if not load_ok:
                reply = "读取拦截词列表失败，请稍后重试。"
            elif word in self.blocked_words:
                reply = f"该词已在拦截列表中：{word}"
            else:
                self.blocked_words.append(word)
                try:
                    await self._save_blocked_words_locked()
                    reply = f"已添加拦截词：{word}\n当前拦截词总数：{len(self.blocked_words)}"
                except Exception as e:
                    logger.error(f"保存拦截词列表失败：{e}")
                    self.blocked_words.remove(word)  # 回滚内存修改
                    reply = "保存拦截词失败，请检查插件存储后重试。"

        yield event.plain_result(reply)

    @filter.permission_type(filter.PermissionType.ADMIN)
    @pblock.command("del")
    async def pblock_del(self, event: AstrMessageEvent):
        """删除拦截词：/pblock del <word>"""
        match = re.match(r"^\s*(?:\[(?:CQ:at|At)[^\]]*\]\s*)?/?pblock\s+del\s+(.+)$", event.message_str.strip(), re.S)
        if not match:
            yield event.plain_result("用法：/pblock del <拦截词>")
            return

        word = match.group(1).strip()
        if not word:
            yield event.plain_result("拦截词不能为空。")
            return

        async with self._lock:
            load_ok = await self._load_blocked_words_locked()
            if not load_ok:
                reply = "读取拦截词列表失败，请稍后重试。"
            elif word not in self.blocked_words:
                reply = f"该词不在拦截列表中：{word}"
            else:
                self.blocked_words.remove(word)
                try:
                    await self._save_blocked_words_locked()
                    reply = f"已删除拦截词：{word}\n当前拦截词总数：{len(self.blocked_words)}"
                except Exception as e:
                    logger.error(f"保存拦截词列表失败：{e}")
                    self.blocked_words.append(word)  # 回滚内存修改
                    reply = "保存拦截词失败，请检查插件存储后重试。"

        yield event.plain_result(reply)

    @filter.permission_type(filter.PermissionType.ADMIN)
    @pblock.command("list")
    async def pblock_list(self, event: AstrMessageEvent):
        """查看当前全部拦截词：/pblock list"""
        async with self._lock:
            load_ok = await self._load_blocked_words_locked()
            if not load_ok:
                yield event.plain_result("读取拦截词列表失败，请稍后重试。")
                return
            words_copy = list(self.blocked_words)

        if not words_copy:
            yield event.plain_result("当前没有拦截词。")
            return

        # 分片输出，避免长列表导致平台截断
        total = len(words_copy)
        chunk_size = 20
        for start in range(0, total, chunk_size):
            chunk = words_copy[start:start + chunk_size]
            lines = "\n".join(
                f"{i + 1}. {word}" for i, word in enumerate(chunk, start=start)
            )
            if start == 0:
                yield event.plain_result(f"当前拦截词列表（共 {total} 个）：\n{lines}")
            else:
                yield event.plain_result(f"拦截词列表续（共 {total} 个）：\n{lines}")

    @filter.permission_type(filter.PermissionType.ADMIN)
    @pblock.command("clear")
    async def pblock_clear(self, event: AstrMessageEvent):
        """清空全部拦截词：/pblock clear"""
        async with self._lock:
            load_ok = await self._load_blocked_words_locked()
            if not load_ok:
                yield event.plain_result("读取拦截词列表失败，请稍后重试。")
                return

            if not self.blocked_words:
                yield event.plain_result("当前没有拦截词，无需清空。")
                return

            old_words = list(self.blocked_words)
            self.blocked_words.clear()
            try:
                await self._save_blocked_words_locked()
                reply = "已清空全部拦截词。"
            except Exception as e:
                logger.error(f"保存拦截词列表失败：{e}")
                self.blocked_words = old_words  # 回滚
                reply = "保存拦截词失败，请检查插件存储后重试。"

        yield event.plain_result(reply)